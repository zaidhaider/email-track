<table class="table">
	<thead>
		<tr>
			<th>Name</th>
			<th>Email</th>
			<th>Address</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>John</td>
			<td>john@gmail.com</td>
			<td>London, UK</td>
		</tr>
		<tr>
			<td>Andy</td>
			<td>andygmail.com</td>
			<td>Merseyside, UK</td>
		</tr>
		<tr>
			<td>Frank</td>
			<td>frank@gmail.com</td>
			<td>Southampton, UK</td>
		</tr>
	</tbody>
</table>