	

<div id="areachart"></div>